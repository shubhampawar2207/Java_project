package controller;

class Events extends WomenBudgetGroup{
	@Override
	public void event(){  // method overriding
		System.out.print("Next upcoming event \nMay 5,2022 \nWomen health awareness\nVenue : Address : ganesh chowk chal,rampur,\nTal - Chiplun , Dist- Ratnagiri, \nState - Maharashtra \n");
		System.out.println("=============================================================================");
		System.out.println("=============================================================================");
	}
}