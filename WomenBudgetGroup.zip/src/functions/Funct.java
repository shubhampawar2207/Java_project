package functions; // package creations
import java.util.*;

public class Funct extends Data{
	Scanner sc = new Scanner(System.in); // Scanner class for user input
	static int num,num1;

public static void sop1(){
	System.out.println("=============================================================================");
	System.out.println("=============================================================================");
	System.out.println();
	System.out.println("Welcome to Happy Women's Budget Group");
	System.out.println("This is your digital assistant Rekha");	
	System.out.println();
	System.out.println("=============================================================================");
	System.out.println("=============================================================================");
}

public static void sop2(){
	System.out.println();
	System.out.println("Options for you");
	System.out.println();
	System.out.println("0.Exit the screen");
	System.out.println("1.Display Happy Budget group information");
	System.out.println("2.Display your information");
	System.out.println("3.Add amount");
	System.out.println("4.Loan options");
	System.out.println("5.Upcoming Event");
	
	System.out.println();
	System.out.println("=============================================================================");
	System.out.println("=============================================================================");
}

public static void sop3(){
	System.out.println();
	System.out.println("=============================================================================");
	System.out.println("=============================================================================");
	System.out.println();
	switch(num){
		case 1:
		sop4(0);
		break;
		case 2:
		sop4(1);
		break;
		case 3:
		sop4(2);
		break;
		case 4:
		sop4(3);
		break;
		case 5:
		sop4(4);
		break;
		case 6:
		sop4(5);
		break;
	}
}

public static void sop4(int i){ // arguments passing in functions 
	System.out.println("Name        :  "+ Data.name[i]);
	System.out.println("Member type :  "+ Data.type[i]);
	System.out.println("Age         :  "+ Data.age[i]);
	System.out.println("=============================================================================");
	System.out.println("=============================================================================");
	

}



public void info(){
	System.out.println();
	System.out.println("Member list");
	sop();
	System.out.println("Your choice according to your name");
	num = sc.nextInt();
	System.out.println();
	sop3();
}

public void loan(){
	System.out.println();
	System.out.println("Loans details");
	System.out.println("1.Amount 30,000 and interest rate 7% for 5 years");
	System.out.println("2.Amount 50,000 and interest rate 7% for 5 years");
	System.out.println("3.Amount 70,000 and interest rate 7% for 5 years");
	System.out.println("4.Amount 100,000 and interest rate 7% for 5 years");
	System.out.println("=============================================================================");
	System.out.println("=============================================================================");
	
	 num1 = sc.nextInt();
	switch(num1){
		case 1:
		lop1(0);
		break;
		case 2:
		lop1(1);
		break;
		case 3:
		lop1(2);
		break;
		case 4:
		lop1(3);
		break; 
		default:
		System.out.println("More loan options will be available soon,\n Please select correct option");
		break;
}
}

    public static void lop1(int i){
	double ans = 0;
	double emi =0;
	ans = (Data.loan[i]*5*7)/100;
	emi = (Data.loan[i] + ans)/60;
	System.out.println("Your total loan amount is "+(Data.loan[i]+ans));
	System.out.println("Your simple interest is "+ans);
	System.out.println("Your monthly installment is  "+String.format("%.2f",emi));
	System.out.println("=============================================================================");
	System.out.println("=============================================================================");
	} 

}