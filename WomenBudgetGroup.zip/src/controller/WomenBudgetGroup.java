package controller;
import java.util.*;
import functions.Funct;
import functions.Data;

interface addmount{ // functional interface
	void add();
}


public class WomenBudgetGroup extends Funct { // mulitlevel inheritance
	
	public void event(){}
	Scanner sc = new Scanner(System.in);
	int choice;
	void call(){
		choice= sc.nextInt();
	}
	
	WomenBudgetGroup(){   // User defined default constructor
		Funct.sop1();	
	}
	
	addmount p1 = () -> { // lambda expression for interface addmount
		System.out.println("Enter three amounts:  ");
		int a =sc.nextInt();
		int b =sc.nextInt();
		int c =sc.nextInt();
		int sum = a+b+c;
		System.out.println("Sum of Entered three amounts is :    "+sum);
		System.out.println("=============================================================================");
		System.out.println("=============================================================================");
		};
		
		

	

public static void main(String... args){
	
	WomenBudgetGroup obj1 = new Events(); // upcasting
	
	
	do{
    
	Funct.sop2(); // static method calling
	obj1.call();  // instance method calling
	
	switch(obj1.choice){  // switch case for choice based
		
		case 1:
		obj1.groupinfo();
		break;
		case 2:
		obj1.info();
		break;
		case 3:
		obj1.p1.add();
		break;
		case 4:
		obj1.loan();
		break;
		case 5:
		obj1.event();
		break;
		default:
		if(obj1.choice == 0)
			break;
		System.out.println("More features will be available soon , Please select correct option");
		break;
		
	} 
	}while(obj1.choice != 0);
	
	


}

}