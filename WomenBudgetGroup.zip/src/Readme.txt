Project name : Women budget group digital assitant

Project members :

095_Shubham kandekar_JH
096_Shubham Pawar_JH




*note : open cmd with src as last directory in path.
        main method in WomenBudgetGroup.java

To compile
javac controller\WomenBudgetGroup.java


To run
java controller.WomenBudgetGroup