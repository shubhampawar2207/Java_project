package functions;


public class Data{
	// array for data holding
public static final String name[] = {"Reshma bhome", "Rani kadam", "Siddhi Gurav", "Avani patil", "Drushti Chalke","Ritu More"};
public static final int age[] = {27,26,30,40,45,27}; 
public static final String type[] ={"member","member","head","accounts","member","member","member"};
public static int bal= 450000;
public static double loan[]={30000,50000,70000,100000};  

protected static void sop(){ 
	System.out.println("1.Reshma bhome");
	System.out.println("2.Rani kadam");
	System.out.println("3.Siddhi Gurav");
	System.out.println("4.Avani patil");
	System.out.println("5.Drushti Chalke");
	System.out.println("6.Ritu More");	
}

public void groupinfo(){
	System.out.println("Name : Happy Women's Budget Group");
	System.out.println("Year : 2015");
	System.out.println("No of members : "+name.length);
	System.out.println("Investment upto date :"+bal);
	System.out.println("Address : rampur, Tal - chiplun , Dist- Ratnagiri, state - Maharashtra ");
	System.out.println("=============================================================================");
	System.out.println("=============================================================================");
}


}

